class Fruit
{
    String name;
    String taste;
    String size;

    Fruit(String name,String taste,String size)
    {
        this.name = name;
        this.taste = taste;
        this.size = size;
    }

    public void eat()
    {
        System.out.println("The fruit's name is:"+name+" "+"Taste:"+taste+" "+"Size:"+size);

    }

}

class Apple extends Fruit
{
    Apple(String name,String taste,String size)
    {
        super(name,taste,size);
    }

    public void eat()
    {
        System.out.println("It is Apple."+"Taste:"+taste+" "+"Size:"+size);
    }
}

class Orange extends Fruit
{
    Orange(String name,String taste,String size)
    {
        super(name,taste,size);
    }

    public void eat()
    {
        System.out.println("It is Orange."+"Taste:"+taste+" "+"Size:"+size);
    }
}

class One
{
    public static void main(String args[])
    {
        Fruit ft = new Apple("Apple","Sweet","Medium");
        ft.eat();

        ft = new Orange("Orange","Sour","Small");
        ft.eat();

    }
}