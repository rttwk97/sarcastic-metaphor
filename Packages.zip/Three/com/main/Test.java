package com.main;
import com.automobile.*;
import com.automobile.twowheeler.*;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Hero ob1 = new Hero();
		Honda ob2 = new Honda();
		
		System.out.println(ob1.getModelName()+" "+ob1.getOwnerName()+" "+ob1.getRegistrationNumber()+" "+ob1.getSpeed());
		ob1.radio();
		
		
		System.out.println(ob2.getModelName()+" "+ob2.getOwnerName()+" "+ob2.getRegistrationNumber()+" "+ob2.getSpeed());
		ob2.cdplayer();
	}

}
