package com.wipro.main;
import com.wipro.automobile.ship.*;

public class Solution {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Compartment ob = new Compartment(10,20,30);
		
		System.out.println("Height:"+ob.getHeight()+"Breadth:"+ob.getBreadth()+"Width:"+ob.getWidth());

	}

}
