/* Create a package called test package.
Define a class called foundation inside the test package.
Inside the class, you need to define 4 integer variables:
var1 with private access modifier
var2 with default access modifier
var3 with protected access modifier
var4 with public access modifier

Import this class and packages in another class. 
Try to access all 4 variables of the foundation class and see what variables are accessible 
and what are not accessible.*/

package test;

public class Foundation
{
	private int v1;
	 int v2;
	protected int v3;
	public int v4;
	
	public Foundation()
	{
		v1=10;
		v2=15;
		v3=20;
		v4=25;
	}
}