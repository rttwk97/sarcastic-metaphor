// Testing which type of variables can be accessed from outside package 

import test.Foundation;

public class Solution extends Foundation
{
	public Solution()
	{
		super();
	}
	
	public static void main(String args[])
	{
		Solution ob = new Solution();
		
		System.out.println("private:"+ob.v1);
		System.out.println("Default:"+ob.v2);
		System.out.println("Protected:"+ob.v3);
		System.out.println("Public:"+ob.v4);
		
	}
}