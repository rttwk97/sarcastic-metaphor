package com.automobile.twowheeler;
import com.automobile.*;

public class Hero extends Vehicle {
	
	public String getModelName()
	{
		return "Hero Glamour Xtreme 2S";
	}
	
	public String getRegistrationNumber()
	{
		return "2154-GH";
	}
	
	public String getOwnerName()
	{
		return "Rittwik Das";
	}
	
	public int getSpeed()
	{
		return 120;
	}
	
	public void radio() 
	{
		System.out.println("Wireless Radio available in the Bike!!");
	}
		

}
