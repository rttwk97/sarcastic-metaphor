package com.automobile.twowheeler;
import com.automobile.*;

public class Honda extends Vehicle {
	
	public String getModelName()
	{
		return "Honda Nisaan M-24JG";
	}
	
	public String getRegistrationNumber()
	{
		return "6564-IO";
	}
	
	public String getOwnerName()
	{
		return "Mira Basu";
	}
	
	public int getSpeed()
	{
		return 140;
	}
	
	public void cdplayer()
	{
		System.out.println("The Bike comes with a cd-player Facility!!");
	}

}
