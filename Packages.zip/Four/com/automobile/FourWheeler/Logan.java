package com.automobile.FourWheeler;
import com.automobile.*;


public class Logan extends Vehicle {
	
	public String getModelName()
	{
		return "Hyundai i20";
	}
	
	public String getRegistrationNumber()
	{
		return "HNQ8-0D";
	}
	
	public String getOwnerName()
	{
		return "Ishani Das";
	}
	
	public int getSpeed()
	{
		return 110;
	}
	
	public int gps()
	{
		return 1414;
	}

}
