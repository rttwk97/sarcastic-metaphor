package com.automobile.FourWheeler;
import com.automobile.*;

public class Ford extends Vehicle {
	
	public String getModelName()
	{
		return "Maruti Suzuki Alto LXI";
	}
	
	public String getRegistrationNumber()
	{
		return "MW8D-IO";
	}
	
	public String getOwnerName()
	{
		return "Rittwik Das";
	}
	
	public int getSpeed()
	{
		return 150;
	}
	
	public int tempControl()
	{
		return 20;
	}

}
