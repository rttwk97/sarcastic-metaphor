package com.main;
import com.automobile.*;
import com.automobile.twowheeler.*;
import com.automobile.FourWheeler.*;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Hero ob1 = new Hero();
		Honda ob2 = new Honda();
		
		//System.out.println(ob1.getModelName()+" "+ob1.getOwnerName()+" "+ob1.getRegistrationNumber()+" "+ob1.getSpeed());
		//ob1.radio();
		
		
		//System.out.println(ob2.getModelName()+" "+ob2.getOwnerName()+" "+ob2.getRegistrationNumber()+" "+ob2.getSpeed());
		//ob2.cdplayer();
		
		Logan ob3 = new Logan();
		Ford  ob4 = new Ford();
		
		System.out.println("Model Name:"+ob3.getModelName()+" "+"Owner:"+ob3.getOwnerName()+" Reg No:"+ob3.getRegistrationNumber()+" Speed:"+ob3.getSpeed()+" GPS:"+ob3.gps());
		System.out.println();
		System.out.println("Model Name:"+ob4.getModelName()+" "+"Owner:"+ob4.getOwnerName()+" Reg No:"+ob4.getRegistrationNumber()+" Speed:"+ob4.getSpeed()+" Temp Control:"+ob4.tempControl());
	}

}
