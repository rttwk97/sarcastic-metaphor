public class TestEmployee
{
    public static void main(String args[])
    {
        Employee emp = new Employee("Sulagna",25000,2020,"ABC123");

        System.out.println("Name:"+emp.getEmp_name()+" "+"Salary:"+emp.get_salary()+" "+"Year:"+emp.get_year()+" "+"Insurance no:"+emp.get_ins_no());

    }
}