public class Employee extends Person
{
        private double sal;
        private int year;
        private String ins_no;

        Employee()
        {
                //for dummy call
        }

        Employee(String emp_name,double a, int b,String c)
        {
            super(emp_name);
            sal=a;
            year=b;
            ins_no=c;
        }

        public String getEmp_name()
        {
           
            return per_name;
        }

        public double get_salary()
        {
            return sal;
        }

        public int get_year()
        {
            return year;
        }

        public String get_ins_no()
        {
            return ins_no;
        }


      
}