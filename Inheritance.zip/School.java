
import java.lang.*;
import java.io.*;
import java.util.*;
class Person
{
	String per_name,DOB;
	Person(String per_name,String DOB)
	{
		this.per_name=per_name;
		this.DOB=DOB;
    }
 
}
class Student extends Person
{
	String StudentID;
	Student(String per_name,String DOB,String StudentID)
	{
		super(per_name,DOB);
		this.StudentID=StudentID;
	}

}
class Teacher extends Person
{
	double salary;
	String sub;
	Teacher(String per_name,String DOB,double salary,String sub)
	{
		super(per_name,DOB);
		this.salary=salary;
		this.sub=sub;
	} 
	String getpname()
	{
		return per_name;
	}
	String getbirth()
	{
		return DOB;
	}
	double getsalary()
	{
		return salary;
	}	
	String getsubject()
	{
		return sub;
	}
}
class CollegeStudent extends Student
{
	int year;
	String major;
	CollegeStudent(String per_name,String DOB,String StudentID,int year,String major)
	{
		super(per_name,DOB,StudentID);
		this.year=year;
		this.major=major;
	}
	String getpname()
	{
		return per_name;
	}
	String getbirth()
	{
		return DOB;
	}
	String getID()
	{
		return StudentID;
	}
	int getyear()
	{
		return year;
	}	
	String getmajor()
	{
		return major;
	}
}	
class College
{
	public static void main(String []args)
	{
		Teacher t=new Teacher("Mr.ABC","01.02.1950",20000,"Computer Science");
		CollegeStudent cs=new CollegeStudent("Sulagna","29.05.1996","CS123",4,"Communications");
		
		System.out.println("Teacher Details:");
		System.out.println("Name:"+t.getpname()+" "+"Date of Birth:"+t.getbirth()+" "+"Salary:"+t.getsalary()+" "+"Subject:"+t.getsubject());
		
		System.out.println("Student Details:");
		System.out.println("Name:"+cs.getpname()+" "+"Date of Birth:"+cs.getbirth()+" "+"Student ID:"+cs.getID()+"  "+"Current Year:"+cs.getyear()+" "+"Major:"+cs.getmajor());
	}
}	