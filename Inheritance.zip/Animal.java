import java.util.*;
import java.lang.*;
import java.io.*;
class Animal
{
	/*Animal()
	{
		System.out.println("A new animal has been created");
	}*/	
	void eat()
	{
		System.out.println("The animal is eating");
	}
	void sleep()
	{
		System.out.println("The animal is sleeping");
	}
}
class Bird extends Animal
{
	/*Bird()
	{
		System.out.println("A new bird has been created");
	}*/
	void eat()
	{
		System.out.println("The bird is eating");
	}
	void sleep()
	{
		System.out.println("The bird is sleeping");
	}
	void fly()
	{
		System.out.println("The bird is flying");
	}	
}
class Zoo
{
	public static void main(String []args)
	{
		Animal a=new Animal();
		a.eat();
		a.sleep();
		Bird b=new Bird();
		b.eat();
		b.sleep();
		b.fly();
	}
}	
	