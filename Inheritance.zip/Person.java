public class Person
{
        public String per_name;
        Person()
        {
            //implicit super constructor
        }

        Person(String str)
        {
            per_name=str;
        }


}