import java.io.*;

class InvalidCountryException extends Exception
{
    public InvalidCountryException(String s)
    {
        super(s);
    }
}

public class UserRegistration
{
    
    void registerUser(String username,String userCountry)
    {
        try
        {

            if(userCountry.equals("India"))
            {
                System.out.println("User registration done successfully");
            }
            else
            {
                throw new InvalidCountryException("User Outside India  cannot be registered");
            }

        }
        catch(InvalidCountryException e)
        {
            System.out.println(e.getMessage());
        }
       
    }
    
    public static void main(String args[]) throws IOException
    {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        String inp = br.readLine();

        String str[] = inp.split(",");

        UserRegistration ob = new UserRegistration();
        ob.registerUser(str[0],str[1]);
    }
}