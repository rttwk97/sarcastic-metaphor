import java.io.*;

public class MathOperation
{
    public static void main(String args[]) throws IOException,ArithmeticException,NumberFormatException
    {
          
            if(args.length >5)
                throw new ArrayIndexOutOfBoundsException();
          int arr[] = new int[5];

           double sum=0;

           double avg=0;

               for(int i=0;i<5;i++)
               {
                   arr[i] = Integer.parseInt(args[i]);
                   sum = sum + arr[i];
               }

               avg = sum/5;

               System.out.println("Sum: "+ sum + " "+ "Average: "+ avg);
           }

    }
