import java.io.*;


public class Nine
{
    public static void main(String args[]) throws IOException
    {

        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Enter the 2 numbers");

        int a = Integer.parseInt(br.readLine());
        int b = Integer.parseInt(br.readLine());

        try
        {
            int c = a/b;
            System.out.println("The quotient of "+a+"/"+b+" = "+c);
        }
        catch(Exception e)
        {
            System.out.println("DivideByZeroException caught");
        }

        finally
        {
            System.out.println("Inside finally block");
        }

    }
}