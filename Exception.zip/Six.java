/*Write a Program to take care of Number Format Exception if user enters values other than integer 
for calculating 
average marks of 2 students. The name of the students and marks in 3 subjects are taken from the
 user while executing the program.
In the same Program write your own Exception classes to take care of Negative values and values
 out of range (i.e. other than in the range of 0-100)*/

import java.io.*;
import java.util.*;

class NegetiveValueException extends Exception
{

}

class InputOutOfRangeException extends Exception
{

}
class Six
{
    public static void main(String args[]) throws IOException
    {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int stu1[] = new int[3];
        int stu2[] = new int[3];
        try
        {
            System.out.println("Enter the Student name:");
            String s1 = br.readLine();
            System.out.println("Enter the marks of 3 subjects for "+ s1 +":");
            for(int i=0;i<3;i++)
            {
                stu1[i] = Integer.parseInt(br.readLine());
                if(stu1[i]<0)
                    throw new NegetiveValueException();
                if(stu1[i]<0 || stu1[i]>100)
                    throw new InputOutOfRangeException();
            }

            System.out.println("Enter the Student name:");
            String s2 = br.readLine();
            System.out.println("Enter the marks of 3 subjects for "+ s2 +":");
            for(int i=0;i<3;i++)
            {
                stu2[i] = Integer.parseInt(br.readLine());
                if(stu2[i]<0)
                    throw new NegetiveValueException();
                if(stu2[i]<0 || stu2[i]>100)
                    throw new InputOutOfRangeException();
            }

            int sum1=0;
            int sum2=0;
            for(int i=0;i<3;i++)
            {
                sum1 = sum1+stu1[i];
                sum2 = sum2+stu2[i];
            }

            double avg1 = sum1/3;
            double avg2 = sum2/3;

            System.out.println(s1+" gets average of: "+ avg1);
            System.out.println(s2+" gets average of: "+ avg2);

        }

        catch(NumberFormatException e)
        {
            System.out.println("Please enter integer number");
        }

        catch(NegetiveValueException e)
        {
            System.out.println("Input number can't be negetive!");
        }

        catch(InputOutOfRangeException e)
        {
            System.out.println("Input number should be in range(0-100)");
        }
    }
}