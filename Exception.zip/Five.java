/* Write a Program with a division method which receives two integer numbers and performs 
the division operation. 

The method should declare that it throws ArithmeticException. This exception should be handled in 
the main method.*/

import java.io.*;

class Five
{
    public int div(int a,int b) throws ArithmeticException
    {
        int res = a/b;

        return res;
    }
        public static void main(String args[]) throws IOException,ArithmeticException
        {
                BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

                int a = Integer.parseInt(br.readLine());
                int b = Integer.parseInt(br.readLine());

                Five ob = new Five();

                try{
                System.out.println(ob.div(a,b));
                }
                catch(Exception e)
                {
                    System.out.println("Entered inputs are not valid!");
                }


        }
}