import java.io.*;
import java.util.*;

class Three
{

    public static void main(String args[]) throws IOException
    {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Enter the number of elements in the array");

        int len = Integer.parseInt(br.readLine());

        int arr[] = new int[len];

        System.out.println("Enter the elements in the array");

        try
        {
            for(int i=0;i<len;i++)
                arr[i] = Integer.parseInt(br.readLine());
       
            System.out.println("Enter the index of the array element you want to access");

            int index = Integer.parseInt(br.readLine());

            

                System.out.println("The array element at index "+ index+" = "+ arr[index]);
                System.out.println("the array element successfully accessed");
        }   

        catch(Exception obj)
        {
                System.out.println(obj.getClass().getName());
        }
    }
}