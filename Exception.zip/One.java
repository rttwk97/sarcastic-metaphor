import java.io.*;
import java.util.*;

class One
{

    public static void main(String args[]) throws IOException
    {
       BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

       try
       {
            System.out.println("Enter an integer:");
            
            int a = Integer.parseInt(br.readLine());

            int b = a * a;

            System.out.println("The square value is "+ b);
            System.out.println("The work has been done successfully");


       }

       catch(Exception e)
       {
            System.out.println("Entered input is not a valid format for an integer.");
       }

    }


}