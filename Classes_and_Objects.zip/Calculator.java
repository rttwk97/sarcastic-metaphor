import java.util.*;
import java.lang.*;
import java.io.*;
class Calculator
{
	static double  p1;
	static double  p2;
	
	static double powerInt(int num1,int num2)
	{
		p1=Math.pow(num1,num2);
		return p1;
	}
		
	static double powerDouble(double num1,int num2)
	{
		p2=Math.pow(num1,num2);
		return p2;
	}
	public static void main(String []args)
	{
		double p11=Calculator.powerInt(2,4);
		double p22=Calculator.powerDouble(2.5,4);
		System.out.println(p11);
		System.out.println(p22);
	}
}