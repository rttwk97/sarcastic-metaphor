 class Box
 {
	 double width;
	 double height;
	 double depth;
	 
	 double volume()
	 {
		 return width * height * depth;
	 }	 
	 Box(double w,double h,double d)
	 {
		 width=w;
		 height=h;
		 depth=d;
	 }
	public static void main(String []args)
	{
		double vol;
		Box b=new Box(10,20,30);
		vol=b.volume();
		System.out.println("The volume is: " +vol);
	}
 }