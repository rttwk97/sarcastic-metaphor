import java.util.Scanner;
import java.lang.*;
import java.io.*;
class Video
{
	String videoName;
	boolean checkout;
	int rating;
	Video(String name)
	{
		videoName=name;
		checkout=false;
		rating=0;
	}
	String getName()
	{
		return videoName;
	}
	void doCheckout()
	{
		checkout=true;
		System.out.println("Video "+videoName+" "+"checked out successfully");
	}
	void doReturn()
	{
		checkout=false;
		System.out.println("Video "+videoName+" "+"returned successfully");
	}
	void recieveRating(int rate)
	{
		rating=rate;
		System.out.println("Rating "+rating+" "+"has been given to the video"+" "+videoName);
	}
	int getRating()
	{
		return rating;
	}
	boolean getCheckout()
	{
		return checkout;
	}
}
class VideoStore
{
	Video[] store =new Video[100];
	int index=-1;
	
	int returnPos(String name)
	{
		int i=0;
		while(i<=index)
		{
			if(store[i].videoName.equals(name))
				return i;
			i++;
		}
		return -1;
	}
	void addVideo(String name)
	{
		if(returnPos(name) < 0)
		{
			store[++index]=new Video(name);
			System.out.println("Video "+ name +" has been added successfully");
		}
		else
			System.out.println("Video already exists");
	}
	void doCheckout(String name)
	{
		int i=returnPos(name);
		store[i].doCheckout();
	}
	void doReturn(String name)
	{
		int i=returnPos(name);
		store[i].doReturn();
	}
	void recieveRating(String name,int rating)
	{
		int i=returnPos(name);
		store[i].recieveRating(rating);
	}
	void listInventory()
	{
		System.out.println("Video Name	|Checkout Status	|Rating");
		if(index < 0)
			System.out.println("No videos to show");
		else
		{
			for(int i=0;i<=index;i++)
				System.out.printf("%-13s	|%15b \t 	|%6d\n",store[i].videoName,store[i].checkout,store[i].rating);
		}
	}
}
class VideoLauncher
{
	public static void main(String []args)
	{
		int c=0;
		String s;
		Scanner sc=new Scanner(System.in);
		VideoStore vs=new VideoStore();
		
		while(true)
		{
			System.out.println("MAIN MENU");
            System.out.println("=========");
            System.out.println("1. Add Videos");
            System.out.println("2. Check Out Video");
            System.out.println("3. Return Video");
            System.out.println("4. Receive Rating");
            System.out.println("5. List Inventory");
            System.out.println("6. Exit.");
            System.out.print("Enter your choice (1..6): ");
            c= sc.nextInt();
            System.out.println();
			switch(c)
			{
				case 1:System.out.println("Enter the video you want to add:");
					   s=sc.next();
					   vs.addVideo(s);
					   System.out.println();
					   break;
				case 2:System.out.println("Enter the video you want to check out:");
					   s=sc.next();
					   vs.doCheckout(s);
					   System.out.println();
					   break;
				case 3:System.out.println("Enter the video you want to return:");
					   s=sc.next();
					   vs.doReturn(s);
					   System.out.println();
					   break;
				case 4:System.out.println("Enter the videos you want to rate:");
					   s=sc.next();
					   System.out.println("Enter the rating:");
					   int n=sc.nextInt();
					   vs.recieveRating(s,n);
					   System.out.println();
					   break;
				case 5:vs.listInventory();
					  System.out.println();
					  break;
				case 6:System.out.println("Thanks for using the application");
					   return ;
			}
		}
	}
}
	
	
		
		
	