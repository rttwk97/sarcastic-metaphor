Wipro TalentNext PBL

Topics Covered: JDBC, Driver Manager, Connection


No. 	Hands-on Assignment 	Topics Covered 	Status

1 	

 Write a java program that establishes a connection to oracle database successfully. If the connection is successful, it should display a message “Connection Established successfully”. In case, it is not able to do so due to any exception, it should display the message “Connection could  not be established “. If there is an exception, it should also display the description of the exception.

	JDBC, Driver Manager, Connection 	

2 	

 In the just concluded exercise, where you have established the connection successfully, exclude the registration process(by commenting the line containing the code Class.forName(“..”)). Observe the result.

	JDBC, Driver Manager, Connection 	