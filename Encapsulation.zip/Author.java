class Author {
	
	private String name;
	private String email;
	private char gender;
	Author(String name, String email, char gender) {
		super();
		this.name = name;
		this.email = email;
		this.gender = gender;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	
	
	public String toString()
	{
		return name + " " + email + " " + gender+ " ";
	}
}



class Book {
	
	private String name;
	private Author author;
	private double price;
	private int qtyInStock;
	Book(String name, Author author, double price, int qtyInStock) {
		super();
		this.name = name;
		this.author = author;
		this.price = price;
		this.qtyInStock = qtyInStock;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Author getAuthor() {
		return author;
	}
	public void setAuthor(Author author) {
		this.author = author;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getQtyInStock() {
		return qtyInStock;
	}
	public void setQtyInStock(int qtyInStock) {
		this.qtyInStock = qtyInStock;
	}
	
	public String toString()
	{
		return name + " " + author + " " + price+ " " +  qtyInStock;
	}

}



public class Encaptulation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Author ob = new Author("Chetan Bhagat","chetan22@gmail.com",'M');
		
		Book bo = new Book("5 point Someone",ob,150,200);
		
		System.out.println("Book details is:"+bo.toString());
		
		Author ob1 = new Author("Lara","la22@gmail.com",'F');

		Book bo1 = new Book("5 point Someone",ob,150,200);
		bo1.setAuthor(ob1);
		bo1.setName("Into the wild");
		
		System.out.println("Book details is:"+bo1.toString());
	}

}
