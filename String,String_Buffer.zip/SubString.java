class SubString
{
	public static void main(String []args)
	{
		String s=args[0];
		int len=s.length();
		
		s=s.substring(1,len-1);
		
		System.out.println(s);
	}
}