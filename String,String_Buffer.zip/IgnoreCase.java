class IgnoreCase
{
	public static void main(String []args)
	{
		String a=args[0];
		String b=args[1];
		
		String temp = "";
        int i = 0;
        while (i + b.length() <= a.length()) {
            String s = a.substring(i, i + b.length());
            if (s.equals(b)) {
                temp += i - 1 >= 0 ? Character.toString(a.charAt(i - 1)) : "";
                temp += i + 2 < a.length() ? Character.toString(a.charAt(i + 2)) : "";
            }
            i++;
        }
        System.out.println(temp);
	}
}