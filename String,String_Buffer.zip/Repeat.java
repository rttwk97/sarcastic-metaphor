class Repeat
{
	public static void main(String []args)
	{
		String s=args[0];
		int n=Integer.parseInt(args[1]);
		
		s=s.substring(s.length()- n);
		
		while(n--!=0)
			System.out.print(s);
	}
}