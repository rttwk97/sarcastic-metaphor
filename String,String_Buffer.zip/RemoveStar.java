class RemoveStar
{
	public static void main(String []args)
	{
		String s=args[0];
		
		int a=s.indexOf('*');
		String temp=s.substring(a-1,a+2);
		s=s.replace(temp,"");
		System.out.println(s);
	}
}