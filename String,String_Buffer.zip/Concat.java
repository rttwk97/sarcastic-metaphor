import java.util.*;
import java.io.*;
import java.lang.*;

class Concat
{
	public static void main(String []args)
	{
		String a=args[0];
		String b=args[1];
		String c=args[2];
		
		a=a.toLowerCase();
		c=c.toLowerCase();
		
		if(a.charAt(a.length()-1) == c.charAt(0))
		{
			a=a.substring(0,a.length()-1);
			System.out.println(a+c);
		}	
		else
			System.out.println(a+" "+c);
		
		
		
	}
}	