class RemoveX
{
	public static void main(String []args)
	{
		String s=args[0];
		int len=s.length();
		
		if(s.charAt(0)=='x' && s.charAt(len-1)=='x')
			s=s.substring(1,len-1);
		System.out.println(s);
	}
}