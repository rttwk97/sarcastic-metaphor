import java.util.*;
import java.lang.*;
import java.io.*;
class Half
{
	public static void main(String []args)
	{
		String s=args[0];
		int len=s.length();
		
		if(len%2!=0)
			System.out.println("null");
		else
		{
			s=s.substring(0,len/2);
			System.out.println(s);
		}
	}
}	