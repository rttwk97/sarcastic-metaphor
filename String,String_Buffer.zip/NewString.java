class NewString
{
	public static void main(String []args)
	{
		String a=args[0];
		String b=args[1];
		
		String c=" ";
		if(args[1]==null)
			System.out.println(a);
		if(a.length()==b.length())
			System.out.println("length of strings cannot be same");
		if(a.length()> b.length())
			c=b+a+b;
		if(a.length()< b.length())
			c=a+b+a;
		
		System.out.println(c);
	}
}