import java.util.*;
import java.lang.*;
import java.io.*;
class Copy

{
	public static void main(String []args)
	{
		String s=args[0];
		int n=s.length();
		
		if(n>=2)
			s=s.substring(0,2);
		
		for(int i=0;i<n;i++)
			System.out.print(s);
	}
}	