class MixString
{
	public static void main(String []args)
	{
		String a=args[0];
		String b=args[1];
		
		int l1=a.length();
		int l2=b.length();
		
		int n=l1 < l2 ? l1 : l2;
		
		String temp="";
		
		for(int i=0;i<n;i++)
			temp+=Character.toString(a.charAt(i)) + Character.toString(b.charAt(i));
		
		if(n==l1)
			temp+=b.substring(n);
		else
			temp+=a.substring(n);
		
		System.out.println(temp);
	}
	
}